/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-B06
 */

#ifndef ti_npi__
#define ti_npi__



#endif /* ti_npi__ */ 
